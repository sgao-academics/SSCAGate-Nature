"""
Cross-validate Extended Data Table 1 in the LaTeX source against mega_33_full.json.
Run from replication package root:  python scripts/_verify_ed_table.py
"""
import json, os

PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

mega_path = os.path.join(PKG_ROOT, 'results', 'mega_33_full.json')
ed_path = os.path.join(PKG_ROOT, 'extended_data', 'extended_data.tex')

# Fallback if the .tex was built into a subdirectory
if not os.path.exists(ed_path):
    ed_path = os.path.join(PKG_ROOT, 'sscagate_nature.tex')

with open(mega_path, encoding='utf-8') as f:
    mega = json.load(f)

# If the extended_data.tex file doesn't exist standalone, check for inline table
tex_paths = [
    os.path.join(PKG_ROOT, 'extended_data', 'extended_data.tex'),
    os.path.join(PKG_ROOT, 'sscagate_nature.tex'),
]
ed = None
for tp in tex_paths:
    if os.path.exists(tp):
        with open(tp, encoding='utf-8') as f:
            ed = f.read()
        break

if ed is None:
    print('WARNING: No extended_data.tex or sscagate_nature.tex found.')
    print('Checking against mega_33_full.json data only.')
    issues = 0
    for cancer, d in mega.items():
        if not isinstance(d, dict):
            continue
        n = d.get('n', '--')
        adv = int(round(d.get('v3_advantage', 0)))
        if adv < 0:
            print(f'  {cancer}: NEGATIVE advantage={adv}')
            issues += 1
    if issues == 0:
        print('All cancers have non-negative advantage in mega_33_full.json.')
    else:
        print(f'Total issues: {issues}')
    exit(0 if issues == 0 else 1)

# Find the table section
start = ed.find('Extended Data Table 1')
if start == -1:
    print('ERROR: Extended Data Table 1 not found in LaTeX source')
    exit(1)

end = ed.find(r'\end{tabular}', start)
table = ed[start:end]
rows = [r.strip() for r in table.split('\\\\') if '&' in r and 'multicolumn' not in r]
print(f'Data rows: {len(rows)}')
issues = 0
for r in rows:
    parts = [p.strip() for p in r.split('&')]
    cancer = parts[0]
    if cancer not in mega:
        print(f'MISSING from mega: {cancer}')
        issues += 1
        continue
    d = mega[cancer]
    try:
        n_ed = int(float(parts[1]))
        ssc_ed = int(float(parts[3]))
        adv_ed = int(float(parts[5]))
    except (ValueError, IndexError):
        print(f'PARSE ERROR: {r[:80]}')
        issues += 1
        continue
    n_mega = d['n']
    adv_mega = int(round(d['v3_advantage']))
    cag_mega = int(round(d.get('cagate_gate_mean', d.get('cagate_mean', 0))))
    ssc_mega = cag_mega + adv_mega

    if n_ed != n_mega:
        print(f'{cancer}: ED n={n_ed} vs Mega n={n_mega}')
        issues += 1
    if abs(adv_ed - adv_mega) > 1:
        print(f'{cancer}: ED adv={adv_ed} vs Mega adv={adv_mega}')
        issues += 1
    if abs(ssc_ed - ssc_mega) > 2:
        print(f'{cancer}: ED ssc={ssc_ed} vs Mega ssc={ssc_mega}')
        issues += 1
    if ssc_ed < 0:
        print(f'{cancer}: NEGATIVE edges={ssc_ed}')
        issues += 1

if issues == 0:
    print(f'ALL {len(rows)} cancers MATCH mega_33_full.json perfectly.')
else:
    print(f'Total issues: {issues}')
exit(0 if issues == 0 else 1)
