#!/usr/bin/env python3
"""
Download TCGA gene expression data from UCSC Xena Browser.
Required for full experiment reproduction. Quick mode uses pre-computed results.

Usage: python scripts/download_tcga.py
Output: data/TCGA_*.tsv (~300MB total for 33 cancers)
"""
import os, sys, time, urllib.request, gzip, shutil

PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PKG_ROOT, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

# 33 TCGA cancer types used in the paper
CANCERS = [
    'ACC','BLCA','BRCA','CESC','CHOL','COAD','DLBC','ESCA','GBM','HNSC',
    'KICH','KIRC','KIRP','LAML','LGG','LIHC','LUAD','LUSC','MESO','OV',
    'PAAD','PCPG','PRAD','READ','SARC','SKCM','STAD','TGCT','THCA','THYM',
    'UCEC','UCS','UVM'
]

# UCSC Xena base URL (TCGA PANCAN gene expression, HiSeqV2)
BASE_URL = 'https://tcga.xenahubs.net/download/TCGA.'
SUFFIX = '.sampleMap/HiSeqV2.gz'

print(f'Downloading {len(CANCERS)} TCGA cancers to {DATA_DIR}/')
print('This may take 10-30 minutes depending on network speed.\n')

downloaded = 0
for i, cancer in enumerate(CANCERS):
    fname = f'TCGA_{cancer}_HiSeqV2.tsv'
    outpath = os.path.join(DATA_DIR, fname)

    if os.path.exists(outpath):
        print(f'  [{i+1:2d}/{len(CANCERS)}] {cancer} - already exists, skip')
        downloaded += 1
        continue

    url = f'{BASE_URL}{cancer}.sampleMap/HiSeqV2.gz'
    gz_path = outpath + '.gz'

    try:
        print(f'  [{i+1:2d}/{len(CANCERS)}] {cancer} - downloading...', end='', flush=True)
        urllib.request.urlretrieve(url, gz_path)
        with gzip.open(gz_path, 'rb') as f_in:
            with open(outpath, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        os.remove(gz_path)
        sz = os.path.getsize(outpath) // 1024 // 1024
        print(f' {sz}MB')
        downloaded += 1
    except Exception as e:
        print(f' FAILED: {e}')
        if os.path.exists(gz_path):
            os.remove(gz_path)
        continue

    time.sleep(0.5)  # be polite

print(f'\nDownloaded: {downloaded}/{len(CANCERS)} cancers')
print(f'Data directory: {DATA_DIR}')
