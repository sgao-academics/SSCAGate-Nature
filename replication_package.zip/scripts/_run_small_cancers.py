"""
Run CAGate on the 6 previously-skipped small cancers.
Strategy: d = min(n-10, 80), K=3, 3 seeds each.
Purpose: Show we didn't skip to hide bad results.
"""
import os, sys, json, time
PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
import torch
from sklearn.cluster import KMeans

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
sys.path.insert(0, os.path.join(PKG_ROOT, 'src'))

DATA_DIR = os.path.join(PKG_ROOT, 'data')
OUT_DIR = os.path.join(PKG_ROOT, 'results')
CANCERS = ['ACC', 'CHOL', 'DLBC', 'KICH', 'UCS', 'UVM']
LR, OUTER, INNER = 0.002, 30, 200
N_SEEDS = 3

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device: {device}')

# Import gate function
try:
    from cluster_aware_loss import cluster_gate
except ImportError:
    # Minimal gate implementation
    import torch.nn.functional as F
    def cluster_gate(res, cid, alpha=0.5):
        d = res.device
        unique_c = torch.unique(cid)
        gates = torch.ones_like(res)
        for c in unique_c:
            mask = (cid == c)
            if mask.sum() < 3: continue
            r_c = res[mask]
            med = torch.median(r_c)
            mad = torch.median(torch.abs(r_c - med))
            if mad < 1e-8: continue
            z = (r_c - med) / mad
            w = torch.sigmoid(-alpha * z)
            gates[mask] = w
        return gates, torch.tensor(0.0)


def run_cagate(X, K=3):
    """Run baseline + CAGate, return (base_edges, gate_edges)."""
    d = X.shape[1]
    results_base = []
    results_gate = []
    
    for seed in range(N_SEEDS):
        # Baseline NOTEARS
        W = torch.zeros(d, d, requires_grad=True, device=device)
        Xg = X.to(device)
        rho, alpha = 1.0, 0.0
        opt = torch.optim.Adam([W], lr=LR)
        for o in range(OUTER):
            for i in range(INNER):
                opt.zero_grad()
                M = torch.eye(d, device=device) - W
                sq = (Xg @ M.T) ** 2
                loss = sq.mean()
                h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
                loss = loss + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
                loss.backward()
                torch.nn.utils.clip_grad_norm_(W, 10.0)
                opt.step()
            with torch.no_grad():
                hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
            if abs(hv) < 1e-8: break
            if abs(hv) > 1e-6: alpha += rho * hv
            rho = min(5*rho, 1e12)
        W_base = W.detach().cpu()
        base_adj = (torch.abs(W_base) > 0.3)
        base_n = base_adj.float().sum().item()
        results_base.append(base_n)
        
        # CAGate
        km = KMeans(n_clusters=K, random_state=seed, n_init=10)
        cid = torch.tensor(km.fit_predict(X.numpy()))
        W2 = torch.zeros(d, d, requires_grad=True, device=device)
        rho, alpha = 1.0, 0.0
        opt2 = torch.optim.Adam([W2], lr=LR)
        for o in range(OUTER):
            for i in range(INNER):
                opt2.zero_grad()
                M = torch.eye(d, device=device) - W2
                sq = (Xg @ M.T) ** 2
                res = sq.mean(dim=1)
                gates, _ = cluster_gate(res, cid.to(device), alpha=0.5)
                loss_d = (gates * sq.sum(dim=1)).sum() / gates.sum().clamp(min=1)
                h = torch.trace(torch.linalg.matrix_exp(W2 * W2)) - d
                loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W2))
                loss.backward()
                torch.nn.utils.clip_grad_norm_(W2, 10.0)
                opt2.step()
            with torch.no_grad():
                hv = (torch.trace(torch.linalg.matrix_exp(W2 * W2)) - d).item()
            if abs(hv) < 1e-8: break
            if abs(hv) > 1e-6: alpha += rho * hv
            rho = min(5*rho, 1e12)
        W_gate = W2.detach().cpu()
        gate_adj = (torch.abs(W_gate) > 0.3)
        gate_n = gate_adj.float().sum().item()
        results_gate.append(gate_n)
    
    base_mean = np.mean(results_base)
    gate_mean = np.mean(results_gate)
    return base_mean, gate_mean, results_base, results_gate


results = {}
for cancer in CANCERS:
    fpath = os.path.join(DATA_DIR, f'TCGA_{cancer}_HiSeqV2.tsv')
    if not os.path.exists(fpath):
        print(f'{cancer}: FILE NOT FOUND')
        continue
    
    df = pd.read_csv(fpath, sep='\t', index_col=0)
    data = df.values.astype(np.float32)
    n, d_full = data.shape[1], data.shape[0]
    d_use = min(n - 10, 80)
    
    # Select top d_use genes by variance
    variances = np.var(data, axis=1)
    top_idx = np.argsort(variances)[-d_use:]
    data_sub = data[top_idx, :]
    
    X = torch.tensor(data_sub.T, dtype=torch.float32)
    X = (X - X.mean(dim=0)) / X.std(dim=0).clamp(min=1e-6)
    
    t0 = time.time()
    base_mean, gate_mean, bases, gates = run_cagate(X, K=3)
    elapsed = time.time() - t0
    delta = gate_mean - base_mean
    
    results[cancer] = {
        'n': n, 'd': d_use,
        'base_mean': base_mean, 'gate_mean': gate_mean,
        'delta': delta,
        'base_per_seed': bases,
        'gate_per_seed': gates,
    }
    
    status = '+' if delta > 0 else ('~' if delta == 0 else '-')
    print(f'{cancer}: n={n}, d={d_use}, base={base_mean:.0f}, gate={gate_mean:.0f}, delta={delta:+.0f} {status} [{elapsed:.0f}s]')

# Save
out_path = os.path.join(OUT_DIR, 'small_cancers_results.json')
with open(out_path, 'w') as f:
    json.dump(results, f, indent=2)

# Summary
pos = sum(1 for v in results.values() if v['delta'] > 0)
neg = sum(1 for v in results.values() if v['delta'] <= 0)
print(f'\nSmall cancers summary: {pos}/{len(results)} positive, {neg}/{len(results)} non-positive')
print(f'Saved to {out_path}')
