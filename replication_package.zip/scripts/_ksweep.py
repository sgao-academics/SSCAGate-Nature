"""
K-sensitivity analysis for CAGate: sweep K=2,3,5,8,10 on 5 representative cancers.
Checks whether CAGate performance depends on pre-specified cluster count.
"""
import os, sys, json, time, statistics, numpy as np, torch
PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
# sys.path removed (use src/ instead)
sys.path.insert(0, os.path.join(PKG_ROOT, 'src'))
from cluster_aware_loss import cluster_gate
from sklearn.cluster import KMeans

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device: {device}')

DATA_DIR = os.path.join(PKG_ROOT, 'data')
CANCERS = ['BLCA', 'READ', 'BRCA', 'GBM', 'LAML']  # diverse: small/large, low/high delta
K_VALUES = [2, 3, 5, 8, 10]
N_SEEDS = 5
N_GENES = 100
LR, OUTER, INNER = 0.002, 30, 200
GATE_ALPHA = 0.5
CKPT_PATH = os.path.join(PKG_ROOT, 'results', 'ksweep_ckpt.json')
RESULT_PATH = os.path.join(PKG_ROOT, 'results', 'ksweep_results.json')
os.makedirs(os.path.dirname(CKPT_PATH), exist_ok=True)

def run_notears(X, gate=False, cid=None):
    d = X.shape[1]
    Xg = X.to(device)
    W = torch.zeros(d, d, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    for o in range(OUTER):
        for i in range(INNER):
            opt.zero_grad()
            M = torch.eye(d, device=device) - W
            sq = (Xg @ M.T) ** 2
            if gate and cid is not None:
                res = sq.mean(dim=1)
                gates, _ = cluster_gate(res, cid.to(device), alpha=GATE_ALPHA)
                loss_d = (gates * sq.sum(dim=1)).sum() / gates.sum().clamp(min=1)
            else:
                loss_d = sq.mean()
            h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
            loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(W, 10.0)
            opt.step()
        with torch.no_grad():
            hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
        if abs(hv) < 1e-8: break
        if abs(hv) > 1e-6: alpha += rho * hv
        rho = min(5*rho, 1e12)
        if torch.isnan(W).any() or torch.isinf(W).any(): break
    return (torch.abs(W.detach().cpu()) > 0.3).float().sum().item()

def load_data(cancer_code):
    fpath = os.path.join(DATA_DIR, f'TCGA_{cancer_code}_HiSeqV2.tsv')
    if not os.path.exists(fpath): return None
    # Load with pandas for robustness (gene names in col 0)
    try:
        import pandas as pd
        df = pd.read_csv(fpath, sep='\t', index_col=0)
        data = df.values.astype(np.float32)
    except:
        # Fallback: manual parsing
        rows = []
        with open(fpath) as f:
            f.readline()  # skip header
            for line in f:
                parts = line.strip().split('\t')
                rows.append([float(x) for x in parts[1:]])
        data = np.array(rows, dtype=np.float32)
    n, d = data.shape[0], data.shape[1]
    if d < 100: return None
    if n > N_GENES:
        variances = np.var(data, axis=1)
        top_idx = np.argsort(variances)[-N_GENES:]
        data = data[top_idx, :]
    X = torch.tensor(data.T, dtype=torch.float32)
    X = (X - X.mean(dim=0)) / X.std(dim=0).clamp(min=1e-6)
    return X

# Load checkpoint
ckpt = {}
if os.path.exists(CKPT_PATH):
    with open(CKPT_PATH) as f: ckpt = json.load(f)

results = {}
t0 = time.time()
total_tasks = len(CANCERS) * len(K_VALUES)
done = 0

for cancer in CANCERS:
    X = load_data(cancer)
    if X is None:
        print(f'{cancer}: SKIP (no data)')
        continue
    n, d = X.shape
    print(f'\n{cancer}: n={n}, d={d}')
    
    for K in K_VALUES:
        key = f'{cancer}_K{K}'
        if key in ckpt:
            results[key] = ckpt[key]
            done += 1
            print(f'  K={K}: [SKIP cached] base={results[key]["base_mean"]:.0f} gate={results[key]["gate_mean"]:.0f} delta={results[key]["delta"]:+.0f}')
            continue
        
        km = KMeans(n_clusters=K, random_state=0, n_init=10)
        cid = torch.tensor(km.fit_predict(X.numpy()))
        
        base_edges, gate_edges = [], []
        for seed in range(N_SEEDS):
            torch.manual_seed(seed)
            be = run_notears(X, gate=False)
            base_edges.append(be)
            ge = run_notears(X, gate=True, cid=cid)
            gate_edges.append(ge)
        
        bm, gm = statistics.mean(base_edges), statistics.mean(gate_edges)
        dm = gm - bm
        results[key] = {'base_mean': bm, 'gate_mean': gm, 'delta': dm, 'base_edges': base_edges, 'gate_edges': gate_edges}
        ckpt[key] = results[key]
        with open(CKPT_PATH, 'w') as f: json.dump(ckpt, f, indent=2)
        done += 1
        elapsed = time.time() - t0
        eta = elapsed/done*(total_tasks-done) if done>0 else 0
        print(f'  K={K}: base={bm:.0f} gate={gm:.0f} delta={dm:+.0f} [{elapsed:.0f}s, eta={eta:.0f}s]')

# Summary
print(f'\n{"="*60}')
print(f'K-sensitivity Results:')
print(f'{"Cancer":<8} {"K=2":>10} {"K=3":>10} {"K=5":>10} {"K=8":>10} {"K=10":>10}')
print(f'{"-"*58}')
for cancer in CANCERS:
    vals = []
    for K in K_VALUES:
        key = f'{cancer}_K{K}'
        if key in results:
            vals.append(f'{results[key]["delta"]:+7.0f}')
        else:
            vals.append('      N/A')
    print(f'{cancer:<8} {vals[0]} {vals[1]} {vals[2]} {vals[3]} {vals[4]}')

print(f'\nBest K per cancer:')
for cancer in CANCERS:
    best_K, best_delta = None, -999
    for K in K_VALUES:
        key = f'{cancer}_K{K}'
        if key in results and results[key]['delta'] > best_delta:
            best_delta = results[key]['delta']
            best_K = K
    print(f'  {cancer}: K={best_K} (delta={best_delta:+.0f})')

# Average across cancers per K
print(f'\nK-sweep average delta:')
for K in K_VALUES:
    deltas = []
    for cancer in CANCERS:
        key = f'{cancer}_K{K}'
        if key in results:
            deltas.append(results[key]['delta'])
    if deltas:
        print(f'  K={K}: mean_delta={statistics.mean(deltas):+.0f}, best_for={sum(1 for c in CANCERS if results.get(f"{c}_K{K}",{}).get("delta",-999)==max(results.get(f"{c}_K{kv}",{}).get("delta",-999) for kv in K_VALUES))} cancers')

with open(RESULT_PATH, 'w') as f:
    json.dump(results, f, indent=2)
print(f'\nResults saved: {RESULT_PATH}')
