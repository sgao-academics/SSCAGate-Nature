"""
K-SWEEP WORKER V2 — Corrected: split by cluster, run NOTEARS per cluster, union edges.
NOT residual gating (which was wrong and produced all-negative deltas).

Required: TCGA .tsv data in ../data/ (download via download_tcga.py first).
"""
import sys, os, json, time, warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import torch
from sklearn.cluster import KMeans

PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CANCER = sys.argv[1]
DATA_DIR = os.path.join(PKG_ROOT, 'data')
OUT_DIR = os.path.join(PKG_ROOT, 'results')
K_VALUES = [2, 3, 5, 8, 10]
N_GENES, N_SEEDS = 100, 5
LR, OUTER, INNER = 0.002, 30, 200

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['OMP_NUM_THREADS'] = '1'

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'[{CANCER}] device={device}', flush=True)

# Load data
fpath = os.path.join(DATA_DIR, f'TCGA_{CANCER}_HiSeqV2.tsv')
df = pd.read_csv(fpath, sep='\t', index_col=0)
X_np = df.T.values.astype(np.float32)
var = np.var(X_np, axis=0)
top_idx = np.argsort(var)[-N_GENES:]
X_np = X_np[:, top_idx]
n_samples, d = X_np.shape
print(f'[{CANCER}] {n_samples} samples x {d} genes', flush=True)


def count_edges(W, thresh=0.3):
    return (torch.abs(W) > thresh).float().sum().item()


def run_notears(X_tensor, seed):
    """Standard NOTEARS on (samples, d) tensor. Returns edge count."""
    np.random.seed(seed)
    torch.manual_seed(seed)
    d_in = X_tensor.shape[1]
    Xt = X_tensor.to(device)
    W = torch.zeros(d_in, d_in, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    h_prev = float('inf')
    for o in range(OUTER):
        for _ in range(INNER):
            opt.zero_grad()
            M = torch.eye(d_in, device=device) - W
            sq = (Xt @ M.T).pow(2)
            loss = sq.mean()
            h_val = torch.trace(torch.linalg.matrix_exp(W * W)) - d_in
            loss = loss + rho * h_val * h_val + alpha * h_val
            loss.backward()
            opt.step()
        with torch.no_grad():
            h_val = torch.trace(torch.linalg.matrix_exp(W * W)) - d_in
        h_curr = h_val.item()
        if h_curr > 0.25 * h_prev if o > 0 else False:
            rho *= 10
        else:
            alpha += rho * h_curr
        h_prev = h_curr
        if h_curr < 1e-8:
            break
    return count_edges(W.detach())


def run_cagate_sweep(X_np_array, K, seed):
    """
    CORRECT CAGate: K-means split -> independent NOTEARS per cluster -> union edges.
    Returns total edge count across all clusters.
    """
    np.random.seed(seed)
    torch.manual_seed(seed)

    # K-means clustering
    km = KMeans(n_clusters=K, random_state=seed, n_init='auto').fit(X_np_array)
    labels = km.labels_

    total_edges = 0
    for c in range(K):
        mask = labels == c
        if mask.sum() < max(5, d + 1):  # too few samples for NOTEARS (need n > d)
            continue
        X_cluster = X_np_array[mask]
        X_t = torch.tensor(X_cluster, dtype=torch.float32)
        try:
            edges = run_notears(X_t, seed + c * 1000)
            total_edges += edges
        except Exception as e:
            print(f'  [WARN] cluster {c} NOTEARS failed: {e}', flush=True)
            continue

    return total_edges


# ---- Main ----
results = {}
X_tensor_full = torch.tensor(X_np, dtype=torch.float32)
t0 = time.time()

# Baseline: NOTEARS on full data
print(f'[{CANCER}] Computing baselines...', flush=True)
base_edges_list = []
for s in range(N_SEEDS):
    seed = 42 + s * 137
    base_edges_list.append(run_notears(X_tensor_full, seed))
base_mean = np.mean(base_edges_list)
base_std = np.std(base_edges_list)
print(f'  baseline: {base_mean:.1f} +/- {base_std:.1f} edges', flush=True)

# K sweep
for K in K_VALUES:
    key = f'{CANCER}_K{K}'
    gate_edges_list = []
    for s in range(N_SEEDS):
        seed = 42 + s * 137
        ge = run_cagate_sweep(X_np, K, seed)
        gate_edges_list.append(ge)

    gate_arr = np.array(gate_edges_list)
    base_arr = np.array(base_edges_list)
    results[key] = {
        'cancer': CANCER, 'K': K,
        'n': int(n_samples),
        'base_mean': float(base_arr.mean()),
        'base_std': float(base_arr.std()),
        'gate_mean': float(gate_arr.mean()),
        'gate_std': float(gate_arr.std()),
        'delta': float(gate_arr.mean() - base_arr.mean()),
        'base_edges': base_arr.tolist(),
        'gate_edges': gate_arr.tolist(),
        'n_seeds': N_SEEDS,
        'method': 'cagate_split'  # distinguishes from wrong residual-gating
    }
    print(f'  K={K}: base={base_arr.mean():.1f}, gate={gate_arr.mean():.1f}, '
          f'delta={gate_arr.mean() - base_arr.mean():.1f}', flush=True)

# Save
out_path = os.path.join(OUT_DIR, f'ksweep_v2_{CANCER}.json')
with open(out_path, 'w', encoding='utf-8') as f:
    json.dump(results, f, indent=2)

print(f'[{CANCER}] Saved {len(results)} results in {(time.time()-t0)/60:.1f}min', flush=True)
