"""
Merge individual ksweep_v2_*.json files into a single ksweep_results.json.
The merged format matches what _gen_all_ed_figures.py expects.
"""
import json, os, glob

PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_DIR = os.path.join(PKG_ROOT, 'results')

merged = {}
for fpath in sorted(glob.glob(os.path.join(RESULTS_DIR, 'ksweep_v2_*.json'))):
    with open(fpath, encoding='utf-8') as f:
        data = json.load(f)
    # keys are like "BLCA_K2", "BLCA_K3" etc.
    for k, v in data.items():
        merged[k] = v

outpath = os.path.join(RESULTS_DIR, 'ksweep_results.json')
with open(outpath, 'w', encoding='utf-8') as f:
    json.dump(merged, f, indent=2)

n_cancers = len(set(k.split('_')[0] for k in merged.keys()))
print(f'[OK] Merged {len(merged)} K-entries across {n_cancers} cancers -> {outpath}')
