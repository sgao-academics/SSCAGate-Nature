"""
Quick test: does the hard-vs-soft clustering phase transition appear with DAGMA-lite?
3 n-values, K-means (hard) vs no clustering (baseline).
"""
import numpy as np
import torch
from sklearn.cluster import KMeans
import pandas as pd, os, time

def dagma_lite(X, lambda1=0.02, lr=0.001, n_iter=3000):
    d = X.shape[1]
    W = torch.zeros(d, d, requires_grad=True)
    Xt = X.clone()
    opt = torch.optim.Adam([W], lr=lr)
    for _ in range(n_iter):
        opt.zero_grad()
        M = torch.eye(d) - W
        loss_mse = (Xt @ M.T).pow(2).mean()
        s = torch.linalg.slogdet(M)
        h = -s.logabsdet
        loss = loss_mse + 0.5 * h + lambda1 * torch.sum(torch.abs(W))
        loss.backward()
        opt.step()
    return W.detach()

def dagma_gated(X, cid, alpha=0.5, lambda1=0.02, lr=0.001, n_iter=3000):
    """DAGMA with cluster-aware gating (hard K-means)."""
    d = X.shape[1]
    W = torch.zeros(d, d, requires_grad=True)
    Xt = X.clone()
    cid_t = cid.clone()
    opt = torch.optim.Adam([W], lr=lr)
    
    for _ in range(n_iter):
        opt.zero_grad()
        M = torch.eye(d) - W
        sq = (Xt @ M.T).pow(2)
        res = sq.mean(dim=1)
        # Gate: per-cluster MAD
        gates = torch.ones_like(res)
        for c in torch.unique(cid_t):
            mask = (cid_t == c)
            if mask.sum() < 3: continue
            r_c = res[mask]
            med = torch.median(r_c)
            mad = torch.median(torch.abs(r_c - med))
            if mad < 1e-8: continue
            gates[mask] = torch.sigmoid(-alpha * (r_c - med) / mad)
        denom = gates.sum().clamp(min=1)
        loss_mse = (gates * sq.sum(dim=1)).sum() / denom
        s = torch.linalg.slogdet(M)
        h = -s.logabsdet
        loss = loss_mse + 0.5 * h + lambda1 * torch.sum(torch.abs(W))
        loss.backward()
        opt.step()
    return W.detach()

def count_edges(W, thresh=0.3):
    return (torch.abs(W) > thresh).float().sum().item()

# Load BRCA
DATA_DIR = os.path.join(PKG_ROOT, 'data')
df = pd.read_csv(os.path.join(DATA_DIR, 'TCGA_BRCA_HiSeqV2.tsv'), sep='\t', index_col=0)
gene_mad = df.apply(lambda x: np.median(np.abs(x - np.median(x))), axis=1)
top_genes = gene_mad.nlargest(100).index
X_full = torch.tensor(df.loc[top_genes].values.T.astype(np.float32))
n_full = len(X_full)
print(f'BRCA: {X_full.shape}')

rng = np.random.RandomState(42)

for n_val in [100, 400, 1200]:
    idx = rng.choice(n_full, min(n_val, n_full), replace=False)
    X = X_full[idx]
    
    t0 = time.time()
    W_base = dagma_lite(X, n_iter=3000)
    edges_base = count_edges(W_base)
    
    km = KMeans(n_clusters=3, random_state=42, n_init=10)
    cid = torch.tensor(km.fit_predict(X.numpy()))
    W_gate = dagma_gated(X, cid, n_iter=3000)
    edges_gate = count_edges(W_gate)
    
    delta = edges_gate - edges_base
    elapsed = time.time() - t0
    flag = 'CAGate wins' if delta > 0 else 'no gain'
    print(f'n={n_val}: base={edges_base:.0f}, gate={edges_gate:.0f}, delta={delta:+.0f} [{flag}] ({elapsed:.0f}s)')
