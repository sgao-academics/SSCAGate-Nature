"""
B=100 bootstrap overnight burn — CAGate vs SSCAGate within-cancer resampling.
2 representative cancers (BRCA + HNSC), 5 n-values, 100 seeds each.
~8-10 hours on RTX 5060. Checkpoint every seed.
"""
import os, sys, json, time, warnings, traceback
PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import torch
from sklearn.cluster import KMeans
from scipy.stats import spearmanr

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['OMP_NUM_THREADS'] = '2'

DATA_DIR = os.path.join(PKG_ROOT, 'data')
OUT_DIR = os.path.join(PKG_ROOT, 'results')
CKPT_PATH = os.path.join(OUT_DIR, 'b100_resample_ckpt.json')
RESULTS_PATH = os.path.join(OUT_DIR, 'b100_resample_results.json')

CANCERS = ['BRCA', 'HNSC']  # 2 representative cancers
N_VALUES = [50, 100, 200, 400, 800]  # 5 n-levels
K, LR, OUTER, INNER = 3, 0.002, 30, 200
N_SEEDS = 100  # B=100 bootstrap power

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device: {device}', flush=True)
print(f'Cancers: {CANCERS}, N_values: {N_VALUES}, Seeds: {N_SEEDS}', flush=True)
print(f'Estimated: {len(CANCERS)*len(N_VALUES)*N_SEEDS} total runs, ~8-10 hours', flush=True)

# ============ NOTEARS CORE ============
def compute_gates(res, cid, alpha=0.5):
    gates = torch.ones_like(res)
    for c in torch.unique(cid):
        mask = (cid == c)
        if mask.sum() < 3: continue
        r_c = res[mask]
        med = torch.median(r_c)
        mad = torch.median(torch.abs(r_c - med))
        if mad < 1e-8: continue
        gates[mask] = torch.sigmoid(-alpha * (r_c - med) / mad)
    return gates

def count_edges(W, thresh=0.3):
    return (torch.abs(W) > thresh).float().sum().item()

def run_baseline(X):
    d = X.shape[1]
    Xg = X.to(device)
    W = torch.zeros(d, d, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    for o in range(OUTER):
        for i in range(INNER):
            opt.zero_grad()
            M = torch.eye(d, device=device) - W
            sq = (Xg @ M.T).pow(2)
            loss_d = sq.mean()
            h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
            loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(W, 10.0)
            opt.step()
        with torch.no_grad():
            hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
        if abs(hv) < 1e-8: break
        if abs(hv) > 1e-6: alpha += rho * hv
        rho = min(5*rho, 1e12)
    return W.detach().cpu()

def run_fixed(X, cid_fixed):
    d = X.shape[1]
    Xg = X.to(device)
    cid_g = cid_fixed.to(device)
    W = torch.zeros(d, d, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    for o in range(OUTER):
        for i in range(INNER):
            opt.zero_grad()
            M = torch.eye(d, device=device) - W
            sq = (Xg @ M.T).pow(2)
            res = sq.mean(dim=1)
            gates = compute_gates(res, cid_g)
            denom = gates.sum().clamp(min=1)
            loss_d = (gates * sq.sum(dim=1)).sum() / denom
            h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
            loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(W, 10.0)
            opt.step()
        with torch.no_grad():
            hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
        if abs(hv) < 1e-8: break
        if abs(hv) > 1e-6: alpha += rho * hv
        rho = min(5*rho, 1e12)
    return W.detach().cpu()

def run_adaptive(X, seed):
    d = X.shape[1]
    Xg = X.to(device)
    W = torch.zeros(d, d, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    rng = np.random.RandomState(seed)
    for o in range(OUTER):
        with torch.no_grad():
            M = torch.eye(d, device=device) - W
            sq_current = (Xg @ M.T).pow(2)
            res_current = sq_current.mean(dim=1).cpu().numpy()
        try:
            km = KMeans(n_clusters=K, random_state=rng.randint(0, 99999), n_init=5)
            cid_current = torch.tensor(km.fit_predict(res_current.reshape(-1, 1)))
        except:
            cid_current = torch.zeros(len(res_current), dtype=torch.long)
        cid_g = cid_current.to(device)
        for i in range(INNER):
            opt.zero_grad()
            M = torch.eye(d, device=device) - W
            sq = (Xg @ M.T).pow(2)
            res = sq.mean(dim=1)
            gates = compute_gates(res, cid_g)
            denom = gates.sum().clamp(min=1)
            loss_d = (gates * sq.sum(dim=1)).sum() / denom
            h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
            loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(W, 10.0)
            opt.step()
        with torch.no_grad():
            hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
        if abs(hv) < 1e-8: break
        if abs(hv) > 1e-6: alpha += rho * hv
        rho = min(5*rho, 1e12)
    return W.detach().cpu()

# ============ LOAD CHECKPOINT ============
if os.path.exists(CKPT_PATH):
    with open(CKPT_PATH) as f:
        ckpt = json.load(f)
    print(f'Resuming from checkpoint: {ckpt.get("completed",0)}/{ckpt.get("total",0)} tasks', flush=True)
else:
    ckpt = {'completed': 0, 'total': len(CANCERS) * len(N_VALUES) * N_SEEDS, 'results': []}

# ============ LOAD DATA ============
data_cache = {}
for cancer in CANCERS:
    # Try multiple naming conventions
    candidates = [
        os.path.join(DATA_DIR, f'{cancer}_top100.tsv'),
        os.path.join(DATA_DIR, f'TCGA_{cancer}_top100.tsv'),
        os.path.join(DATA_DIR, f'TCGA_{cancer}_HiSeqV2.tsv'),
    ]
    path = None
    for p in candidates:
        if os.path.exists(p):
            path = p
            break
    if path is None:
        print(f'[SKIP] {cancer}: no data file found', flush=True)
        continue
    
    df = pd.read_csv(path, sep='\t', index_col=0)
    
    # TSV is genes(rows) X samples(columns). Select top 100 genes by MAD.
    if df.shape[0] > 100:
        # MAD per gene (per row) — genes with highest expression variance
        gene_mad = df.apply(lambda x: np.median(np.abs(x - np.median(x))), axis=1)
        top_genes = gene_mad.nlargest(100).index
        df = df.loc[top_genes]
    
    # Transpose: genes x samples -> samples x genes
    X = torch.tensor(df.values.T.astype(np.float32), dtype=torch.float32)
    data_cache[cancer] = X
    print(f'Loaded {cancer}: {X.shape[0]} samples x {X.shape[1]} genes from {path}', flush=True)

# ============ BURN ============
results = ckpt.get('results', [])
completed = ckpt.get('completed', 0)
task_id = completed

for cancer in CANCERS:
    if cancer not in data_cache: continue
    X_full = data_cache[cancer]
    n_full = len(X_full)
    
    for n_val in N_VALUES:
        if n_val > n_full:
            print(f'[SKIP] {cancer} n={n_val} > n_full={n_full}', flush=True)
            task_id += N_SEEDS
            continue
        
        print(f'\n=== {cancer} n={n_val} (n_full={n_full}) ===', flush=True)
        t_start = time.time()
        
        base_edges = []
        fixed_edges = []
        adaptive_edges = []
        
        for seed in range(N_SEEDS):
            if task_id < completed:
                task_id += 1
                continue
            
            try:
                rng = np.random.RandomState(seed * 1000 + n_val)
                idx = rng.choice(n_full, min(n_val, n_full), replace=False)
                X_sub = X_full[idx]
                
                Wb = run_baseline(X_sub)
                base_edges.append(count_edges(Wb))
                
                km = KMeans(n_clusters=K, random_state=seed, n_init=10)
                cid = torch.tensor(km.fit_predict(X_sub.numpy()))
                Wf = run_fixed(X_sub, cid)
                fixed_edges.append(count_edges(Wf))
                
                Wa = run_adaptive(X_sub, seed)
                adaptive_edges.append(count_edges(Wa))
                
                task_id += 1
                
                # Checkpoint every 5 seeds
                if seed % 5 == 0 or seed == N_SEEDS - 1:
                    elapsed = time.time() - t_start
                    done = seed + 1
                    eta = elapsed / done * (N_SEEDS - done)
                    print(f'  [{cancer} n={n_val}] seed {done}/{N_SEEDS} ({elapsed:.0f}s elapsed, ETA {eta:.0f}s)', flush=True)
                    ckpt['completed'] = task_id
                    ckpt['results'] = results
                    with open(CKPT_PATH, 'w') as f:
                        json.dump(ckpt, f)
                    
            except Exception as e:
                print(f'  [ERR] {cancer} n={n_val} seed={seed}: {e}', flush=True)
                task_id += 1
                continue
        
        if len(base_edges) >= N_SEEDS * 0.9:
            b_m = np.mean(base_edges)
            f_m = np.mean(fixed_edges)
            a_m = np.mean(adaptive_edges)
            v3_adv = a_m - f_m
            
            from scipy.stats import spearmanr
            result = {
                'cancer': cancer,
                'n': n_val,
                'n_full': n_full,
                'baseline': float(b_m),
                'baseline_std': float(np.std(base_edges)),
                'cagate': float(f_m),
                'cagate_std': float(np.std(fixed_edges)),
                'sscagate': float(a_m),
                'sscagate_std': float(np.std(adaptive_edges)),
                'v3_advantage': float(v3_adv),
                'v3_advantage_std': float(np.std([a - f for a, f in zip(adaptive_edges, fixed_edges)])),
                'n_seeds_success': len(base_edges),
            }
            results.append(result)
            
            elapsed = time.time() - t_start
            print(f'  DONE n={n_val} [{elapsed:.0f}s]: base={b_m:.0f}+-{np.std(base_edges):.0f}, '
                  f'CAG={f_m:.0f}+-{np.std(fixed_edges):.0f}, SSC={a_m:.0f}+-{np.std(adaptive_edges):.0f}, '
                  f'V3={v3_adv:+.1f}+-{np.std([a-f for a,f in zip(adaptive_edges,fixed_edges)]):.1f}', flush=True)
        else:
            print(f'  [FAIL] {cancer} n={n_val}: only {len(base_edges)}/{N_SEEDS} seeds', flush=True)

# ============ SAVE FINAL ============
ckpt['completed'] = task_id
ckpt['results'] = results
with open(CKPT_PATH, 'w') as f:
    json.dump(ckpt, f)
with open(RESULTS_PATH, 'w') as f:
    json.dump(results, f, indent=2)

# Summary
print(f'\n{"="*60}')
print(f'B=100 BURN COMPLETE')
print(f'Total tasks: {task_id}/{ckpt["total"]}')
print(f'Results: {len(results)} configurations')
for r in results:
    print(f'  {r["cancer"]} n={r["n"]}: V3={r["v3_advantage"]:+.1f}+-{r["v3_advantage_std"]:.1f}')
print(f'Results saved to {RESULTS_PATH}')
print(f'{"="*60}')
