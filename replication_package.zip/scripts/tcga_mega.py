#!/usr/bin/env python3
"""
TCGA MEGA SWEEP — 3-stage chain, ~2.5 hours
T1: SSCAGate d=100/200 on 20 cancers (~50min)
T2: CAGate d=200 on same cancers (~20min)
T3: SSCAGate d=300 on large cancers + summary plots (~30min)
All stages checkpointed — crash-safe resume.

Required: pip install cdsm + download TCGA data via download_tcga.py
"""
import sys, os, json, time, warnings, glob, numpy as np, pandas as pd
warnings.filterwarnings('ignore')
PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
try:
    from cdsm.gate.sscagate import discover_sscagate
    from cdsm.gate.cagate import CAGate, CAGateConfig
except ImportError:
    sys.path.insert(0, os.path.join(PKG_ROOT, 'src'))
    from cdsm.gate.sscagate import discover_sscagate
    from cdsm.gate.cagate import CAGate, CAGateConfig

data_dir = os.path.join(PKG_ROOT, 'data')
out_dir = os.path.join(PKG_ROOT, 'results', '_tcga_sweep')
os.makedirs(out_dir, exist_ok=True)

def load_ckpt(name):
    path = os.path.join(out_dir, f'{name}.json')
    return json.load(open(path)) if os.path.exists(path) else {}

def save_ckpt(name, data):
    with open(os.path.join(out_dir, f'{name}.json'), 'w') as f:
        json.dump(data, f, indent=2, default=str)

def load_tcga(fpath):
    df = pd.read_csv(fpath, sep='\t', index_col=0)
    X = df.values.T.astype(np.float32)
    return X

tsv_files = sorted(glob.glob(os.path.join(data_dir, 'TCGA_*_HiSeqV2.tsv')))
print(f'{len(tsv_files)} TCGA cancers found', flush=True)

# ── T1: SSCAGate d=100/200 ──
r1 = load_ckpt('t1_sscagate')
if len(r1) < 40:
    print('T1: SSCAGate d=100/200', flush=True)
    for fpath in tsv_files[:20]:
        cancer = os.path.basename(fpath).replace('TCGA_','').replace('_HiSeqV2.tsv','')
        for d_use in [100, 200]:
            name = f'{cancer}_d{d_use}'
            if name in r1: continue
            try: X = load_tcga(fpath)
            except: continue
            n, d_raw = X.shape
            if d_use > d_raw: continue
            idx = np.argsort(-X.var(axis=0))[:d_use]
            X_sub = X[:, idx]
            X_sub = (X_sub - X_sub.mean(0)) / (X_sub.std(0) + 1e-8)
            t1 = time.time()
            r = discover_sscagate(X_sub, n_seeds=5)
            r1[name] = {'cancer':cancer,'d':d_use,'n':n,
                        'ss_base':round(float(r.base_mean),1),
                        'ss_gate':round(float(r.gate_mean),1),
                        'ss_delta':round(float(r.delta),1),
                        'ss_phase':r.phase_regime,'time':round(time.time()-t1,1)}
            save_ckpt('t1_sscagate', r1)
            print(f'  {name}: base={r.base_mean:.0f} gate={r.gate_mean:.0f} ({r.delta:+.0f}) {r.phase_regime}', flush=True)
    print(f'T1 done: {len(r1)} configs', flush=True)
else:
    print(f'T1: {len(r1)} configs (skip)', flush=True)

# ── T2: CAGate d=200 on same cancers ──
r2 = load_ckpt('t2_cagate')
if len(r2) < 20:
    print('T2: CAGate d=200', flush=True)
    for fpath in tsv_files[:20]:
        cancer = os.path.basename(fpath).replace('TCGA_','').replace('_HiSeqV2.tsv','')
        name = cancer
        if name in r2: continue
        try: X = load_tcga(fpath)
        except: continue
        n, d_raw = X.shape
        d_use = min(200, d_raw)
        idx = np.argsort(-X.var(axis=0))[:d_use]
        X_sub = X[:, idx]
        X_sub = (X_sub - X_sub.mean(0)) / (X_sub.std(0) + 1e-8)
        edges, times = [], []
        for s in range(5):
            t1 = time.time()
            cfg = CAGateConfig(k=3, seed=s, outer=30, inner=200, lr=0.002)
            res = CAGate(cfg).discover(X_sub.copy(), use_gate=True, verbose=False)
            edges.append(res.n_edges); times.append(time.time()-t1)
        r2[name] = {'cancer':cancer,'d':d_use,'n':n,
                    'ca_edges':round(float(np.mean(edges)),1),
                    'ca_time':round(float(np.mean(times)),1)}
        save_ckpt('t2_cagate', r2)
        print(f'  {name}: {r2[name]["ca_edges"]:.0f} edges', flush=True)
    print(f'T2 done: {len(r2)} configs', flush=True)
else:
    print(f'T2: {len(r2)} configs (skip)', flush=True)

# ── T3: SSCAGate d=300 on large cancers (n>300) + plots ──
r3 = load_ckpt('t3_d300')
if len(r3) < 9:
    print('T3: SSCAGate d=300 on large cancers', flush=True)
    for fpath in tsv_files[:20]:
        cancer = os.path.basename(fpath).replace('TCGA_','').replace('_HiSeqV2.tsv','')
        if cancer in r3: continue
        try: X = load_tcga(fpath)
        except: continue
        n, d_raw = X.shape
        if n <= 300: continue
        d_use = min(300, d_raw)
        idx = np.argsort(-X.var(axis=0))[:d_use]
        X_sub = X[:, idx]
        X_sub = (X_sub - X_sub.mean(0)) / (X_sub.std(0) + 1e-8)
        t1 = time.time()
        try:
            r = discover_sscagate(X_sub, n_seeds=5)
            r3[cancer] = {'d':d_use,'n':n,
                          'ss_base':round(float(r.base_mean),1),
                          'ss_gate':round(float(r.gate_mean),1),
                          'ss_delta':round(float(r.delta),1),
                          'time':round(time.time()-t1,1)}
        except Exception as e: r3[cancer] = {'error':str(e)[:100]}
        save_ckpt('t3_d300', r3)
        print(f'  {cancer}: gate={r3[cancer].get("ss_gate","?")} edges', flush=True)
    print(f'T3 done: {len(r3)} configs', flush=True)
else:
    print(f'T3: {len(r3)} configs (skip)', flush=True)

# ── Summary ──
print(f'\n{"="*65}')
print(f'{"Cancer":<8} {"n":>5} {"SS100":>7} {"SS200":>7} {"CA200":>7} {"SS300":>7} {"Phase":>16}')
print(f'{"-"*65}')
for cancer in sorted(set(r['cancer'] for r in r1.values())):
    s100 = r1.get(f'{cancer}_d100',{})
    s200 = r1.get(f'{cancer}_d200',{})
    ca200 = r2.get(cancer,{})
    s300 = r3.get(cancer,{})
    n_val = s100.get('n', s200.get('n', ca200.get('n', 0)))
    ss100 = f'{s100.get("ss_gate",0):.0f}' if s100 else '-'
    ss200 = f'{s200.get("ss_gate",0):.0f}' if s200 else '-'
    ca200v = f'{ca200.get("ca_edges",0):.0f}' if ca200 else '-'
    ss300v = f'{s300.get("ss_gate",0):.0f}' if s300 else '-'
    phase = s100.get('ss_phase', s200.get('ss_phase', '-'))
    print(f'{cancer:<8} {n_val:>5} {ss100:>7} {ss200:>7} {ca200v:>7} {ss300v:>7} {phase:>16}')

deltas_100 = [r['ss_delta'] for r in r1.values() if r.get('d')==100]
deltas_200 = [r['ss_delta'] for r in r1.values() if r.get('d')==200]
print(f'\nAvg SS delta: d100={np.mean(deltas_100):+.0f}, d200={np.mean(deltas_200):+.0f}')

# Save full merge
full = {'t1':r1, 't2':r2, 't3':r3}
save_ckpt('full_merge', full)
print(f'ALL DONE. Results in {out_dir}/')
