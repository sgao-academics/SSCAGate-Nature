"""
CROSS-DOMAIN PHASE TRANSITION — Within-cancer resampling (OFFLINE, fault-tolerant).
V2: Per-task checkpointing, crash recovery, CUDA memory mgmt.
"""
import os, sys, json, time, warnings, traceback
PKG_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import torch
from sklearn.cluster import KMeans
from scipy.stats import spearmanr

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['OMP_NUM_THREADS'] = '2'

DATA_DIR = os.path.join(PKG_ROOT, 'data')
OUT_DIR = os.path.join(PKG_ROOT, 'results')
CKPT_PATH = os.path.join(OUT_DIR, 'resample_phase_ckpt.json')
RESULTS_PATH = os.path.join(OUT_DIR, 'resample_phase_results.json')

CANCERS = ['BRCA', 'KIRC', 'THCA', 'LUAD', 'LUSC', 'HNSC', 'LGG', 'LIHC']
N_VALUES = [50, 100, 200, 400]
K, LR, OUTER, INNER = 3, 0.002, 30, 200
N_SEEDS = 3

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'Device: {device}', flush=True)

def compute_gates(res, cid, alpha=0.5):
    gates = torch.ones_like(res)
    for c in torch.unique(cid):
        mask = (cid == c)
        if mask.sum() < 3: continue
        r_c = res[mask]
        med = torch.median(r_c)
        mad = torch.median(torch.abs(r_c - med))
        if mad < 1e-8: continue
        gates[mask] = torch.sigmoid(-alpha * (r_c - med) / mad)
    return gates

def count_edges(W, thresh=0.3):
    return (torch.abs(W) > thresh).float().sum().item()

def run_baseline(X):
    d = X.shape[1]
    Xg = X.to(device)
    W = torch.zeros(d, d, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    for o in range(OUTER):
        for i in range(INNER):
            opt.zero_grad()
            M = torch.eye(d, device=device) - W
            sq = (Xg @ M.T).pow(2)
            loss_d = sq.mean()
            h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
            loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(W, 10.0)
            opt.step()
        with torch.no_grad():
            hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
        if abs(hv) < 1e-8: break
        if abs(hv) > 1e-6: alpha += rho * hv
        rho = min(5*rho, 1e12)
    return W.detach().cpu()

def run_fixed(X, cid_fixed):
    d = X.shape[1]
    Xg = X.to(device)
    cid_g = cid_fixed.to(device)
    W = torch.zeros(d, d, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    for o in range(OUTER):
        for i in range(INNER):
            opt.zero_grad()
            M = torch.eye(d, device=device) - W
            sq = (Xg @ M.T).pow(2)
            res = sq.mean(dim=1)
            gates = compute_gates(res, cid_g)
            denom = gates.sum().clamp(min=1)
            loss_d = (gates * sq.sum(dim=1)).sum() / denom
            h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
            loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(W, 10.0)
            opt.step()
        with torch.no_grad():
            hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
        if abs(hv) < 1e-8: break
        if abs(hv) > 1e-6: alpha += rho * hv
        rho = min(5*rho, 1e12)
    return W.detach().cpu()

def run_adaptive(X, seed):
    d = X.shape[1]
    Xg = X.to(device)
    W = torch.zeros(d, d, requires_grad=True, device=device)
    rho, alpha = 1.0, 0.0
    opt = torch.optim.Adam([W], lr=LR)
    rng = np.random.RandomState(seed)
    for o in range(OUTER):
        with torch.no_grad():
            M = torch.eye(d, device=device) - W
            sq_current = (Xg @ M.T).pow(2)
            res_current = sq_current.mean(dim=1).cpu().numpy()
        try:
            km = KMeans(n_clusters=K, random_state=rng.randint(0, 99999), n_init=5)
            cid_current = torch.tensor(km.fit_predict(res_current.reshape(-1, 1)))
        except:
            cid_current = torch.zeros(len(res_current), dtype=torch.long)
        cid_g = cid_current.to(device)
        for i in range(INNER):
            opt.zero_grad()
            M = torch.eye(d, device=device) - W
            sq = (Xg @ M.T).pow(2)
            res = sq.mean(dim=1)
            gates = compute_gates(res, cid_g)
            denom = gates.sum().clamp(min=1)
            loss_d = (gates * sq.sum(dim=1)).sum() / denom
            h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
            loss = loss_d + 0.5*rho*h**2 + alpha*h + 0.01*torch.sum(torch.abs(W))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(W, 10.0)
            opt.step()
        with torch.no_grad():
            hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
        if abs(hv) < 1e-8: break
        if abs(hv) > 1e-6: alpha += rho * hv
        rho = min(5*rho, 1e12)
    return W.detach().cpu()

def run_single_task(cancer, n_val, n_full, X_full):
    """Run one (cancer, n) task. Returns result dict or None on failure."""
    t0 = time.time()
    bases, fixeds, adaptives = [], [], []
    
    for seed in range(N_SEEDS):
        try:
            rng = np.random.RandomState(seed * 1000 + n_val)
            idx = rng.choice(n_full, min(n_val, n_full), replace=False)
            X_sub = X_full[idx]
            
            # Baseline
            Wb = run_baseline(X_sub)
            bases.append(count_edges(Wb))
            
            # Fixed (CAGate)
            km = KMeans(n_clusters=K, random_state=seed, n_init=10)
            cid = torch.tensor(km.fit_predict(X_sub.numpy()))
            Wf = run_fixed(X_sub, cid)
            fixeds.append(count_edges(Wf))
            
            # Adaptive (SSCAGate)
            Wa = run_adaptive(X_sub, seed)
            adaptives.append(count_edges(Wa))
            
        except Exception as e:
            print(f'  [WARN] {cancer} n={n_val} seed={seed} failed: {e}', flush=True)
            continue
    
    if len(bases) < N_SEEDS:
        print(f'  [FAIL] {cancer} n={n_val}: only {len(bases)}/{N_SEEDS} seeds succeeded, skipping', flush=True)
        return None
    
    b_m = np.mean(bases); f_m = np.mean(fixeds); a_m = np.mean(adaptives)
    v3_adv = a_m - f_m
    elapsed = time.time() - t0
    
    result = {
        'cancer': cancer, 'n': n_val, 'n_full': n_full,
        'baseline': float(b_m),
        'fixed_delta': float(f_m - b_m),
        'adaptive_delta': float(a_m - b_m),
        'v3_advantage': float(v3_adv),
    }
    
    print(f'  OK n={n_val}: base={b_m:.0f}, fixed=+{f_m-b_m:.0f}, adaptive=+{a_m-b_m:.0f}, V3_adv={v3_adv:+.1f} [{elapsed:.0f}s]', flush=True)
    return result

# ─── Main loop with fault tolerance ───
# Load checkpoint (NOW STORES FULL RESULTS)
ckpt = {}
if os.path.exists(CKPT_PATH):
    try:
        with open(CKPT_PATH) as f:
            ckpt = json.load(f)
        print(f'Resumed: {len(ckpt.get("results", {}))} tasks completed', flush=True)
    except:
        print('Checkpoint corrupt, starting fresh', flush=True)
        ckpt = {'results': {}}

if 'results' not in ckpt:
    ckpt['results'] = {}

n_total = len(CANCERS) * len(N_VALUES)
task_idx = len(ckpt['results'])

for ci, cancer in enumerate(CANCERS):
    fpath = os.path.join(DATA_DIR, f'TCGA_{cancer}_HiSeqV2.tsv')
    if not os.path.exists(fpath):
        print(f'{cancer}: FILE NOT FOUND, skipping', flush=True)
        continue
    
    df = pd.read_csv(fpath, sep='\t', index_col=0)
    data = df.values.astype(np.float32)
    n_full, d_raw = data.shape[1], data.shape[0]
    d_use = 100
    variances = np.var(data, axis=1)
    top_idx = np.argsort(variances)[-d_use:]
    data_sub = data[top_idx, :]
    X_full = torch.tensor(data_sub.T, dtype=torch.float32)
    X_full = (X_full - X_full.mean(dim=0)) / X_full.std(dim=0).clamp(min=1e-6)
    print(f'\n{cancer}: n_full={n_full}, d={d_use}', flush=True)
    
    for n_val in N_VALUES:
        task_id = f'{cancer}_{n_val}'
        if task_id in ckpt['results']:
            prev = ckpt['results'][task_id]
            print(f'  [SKIP] {task_id} (V3_adv={prev["v3_advantage"]:+.1f})', flush=True)
            continue
        
        result = run_single_task(cancer, n_val, n_full, X_full)
        
        if result is not None:
            ckpt['results'][task_id] = result
            task_idx += 1
            print(f'  [{task_idx}/{n_total}] {task_id} done', flush=True)
        else:
            print(f'  [{task_idx}/{n_total}] {task_id} FAILED (will retry on next run)', flush=True)
        
        # Save checkpoint IMMEDIATELY after each task
        with open(CKPT_PATH, 'w') as f:
            json.dump(ckpt, f)
        
        # Also save full results incrementally
        with open(RESULTS_PATH, 'w') as f:
            json.dump(ckpt, f, indent=2)
        
        # Clear CUDA cache between tasks
        if device.type == 'cuda':
            torch.cuda.empty_cache()

# ─── Final summary ───
results = ckpt['results']
print('\n' + '='*60, flush=True)
print('WITHIN-CANCER RESAMPLING RESULTS', flush=True)
print('='*60, flush=True)

for cancer in CANCERS:
    cancer_results = [(k, v) for k, v in results.items() if v.get('cancer') == cancer]
    if not cancer_results: continue
    cancer_results.sort(key=lambda x: x[1]['n'])
    ns = [v['n'] for _, v in cancer_results]
    advs = [v['v3_advantage'] for _, v in cancer_results]
    print(f'\n{cancer} (n_full={cancer_results[0][1]["n_full"]}):', flush=True)
    for (_, v) in cancer_results:
        print(f'  n={v["n"]:>4}: fixed=+{v["fixed_delta"]:>5.0f}, adaptive=+{v["adaptive_delta"]:>5.0f}, V3_adv={v["v3_advantage"]:+>5.0f}', flush=True)
    if len(ns) >= 3:
        r, p = spearmanr(ns, advs)
        print(f'  Spearman r(n, V3_adv) = {r:.3f} (p={p:.4f})', flush=True)

all_ns = [v['n'] for v in results.values()]
all_advs = [v['v3_advantage'] for v in results.values()]
r_all, p_all = spearmanr(all_ns, all_advs)
print(f'\nAGGREGATE: r(n, V3_adv) = {r_all:.3f} (p={p_all:.4f})', flush=True)
print(f'Phase transition within-cancer: {"YES" if r_all > 0.5 and p_all < 0.05 else "WEAK/NO"}', flush=True)

with open(RESULTS_PATH, 'w') as f:
    json.dump({'results': results, 'spearman_r': float(r_all), 'spearman_p': float(p_all), 'n_cancer_types': len(CANCERS), 'aggregate': {str(n): float(np.mean([v['v3_advantage'] for v in results.values() if v['n'] == n])) for n in N_VALUES}}, f, indent=2)
print(f'\nSaved to {RESULTS_PATH}', flush=True)
