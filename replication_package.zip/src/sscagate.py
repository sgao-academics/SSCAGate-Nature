"""
SSCAGate: Self-Supervised Cluster-Aware Gate for Causal Discovery (V3)
========================================================================
Core innovation: Jointly learns cluster assignments AND causal graph,
eliminating the need for pre-specified K-means clustering.

Math:
    min_{W,P}  L_recon(W,P) + λ·h(W)² + β·H(P) + γ·||W||₁
    
    where:
    - W: causal adjacency matrix (NOTEARS DAG constraint h(W))
    - P: learnable cluster assignment (n×K, softmax over K)
    - L_recon: gated reconstruction loss using P-soft clusters
    - H(P): entropy regularization preventing degenerate clusters
    - Gate: γ_k = σ(σ_res_k / median(σ_res))⁻¹  [same as CAGate]

Key difference from CAGate:
    CAGate:  cid = KMeans(X), gate = f(residuals | cid)
    SSCAGate: P = learnable, gate = f(residuals | soft clusters from P)

Reference: Gao et al. (2026) CAGate: Cluster-Aware Gating...
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class SSCAGate(nn.Module):
    """
    Self-supervised cluster-aware gate for NOTEARS-style causal discovery.
    
    Args:
        d: number of variables (genes)
        K: number of clusters (can be larger than true K - entropy reg prunes excess)
        lr_W: learning rate for causal graph W
        lr_P: learning rate for cluster assignments
        lambda_dag: DAG constraint weight
        beta_entropy: entropy regularization weight (higher = more uniform clusters)
        gamma_l1: L1 sparsity on W
        gate_alpha: gate sharpness (same as CAGate)
    """
    
    def __init__(self, d, K=10, lr_W=0.002, lr_P=0.01, 
                 lambda_dag=0.5, beta_entropy=0.1, gamma_l1=0.01,
                 gate_alpha=0.5, outer=30, inner=200):
        super().__init__()
        self.d = d
        self.K = K
        self.lr_W = lr_W
        self.lr_P = lr_P
        self.lambda_dag = lambda_dag
        self.beta_entropy = beta_entropy
        self.gamma_l1 = gamma_l1
        self.gate_alpha = gate_alpha
        self.outer = outer
        self.inner = inner
        
        # Causal adjacency matrix (NOTEARS parameterization)
        self.W = nn.Parameter(torch.zeros(d, d))
        
        # Cluster assignment logits (n samples will be set during fit)
        self.P_logits = None  # Will be initialized per dataset
        
    def initialize_assignments(self, n, device='cpu'):
        """Initialize soft cluster assignments (n×K)."""
        # Random init near uniform → entropy regularization will shape it
        self.P_logits = nn.Parameter(
            torch.randn(n, self.K, device=device) * 0.1
        )
        return self.P_logits
    
    def get_soft_clusters(self):
        """Get soft cluster assignment probabilities (n×K)."""
        return F.softmax(self.P_logits, dim=1)
    
    def get_hard_clusters(self):
        """Get hard cluster assignments (n,)."""
        P = self.get_soft_clusters()
        return P.argmax(dim=1)
    
    def compute_cluster_gates(self, residuals, P_soft):
        """
        Compute per-sample gate weights using soft cluster assignments.
        
        For each cluster k:
            σ_k = weighted std of residuals in cluster k
            gate_k = σ(α · (σ_median / σ_k - 1))
        
        Then per-sample gate = Σ_k P_ik · gate_k  (soft assignment-weighted)
        
        Args:
            residuals: (n,) per-sample reconstruction residuals
            P_soft: (n, K) soft cluster probabilities
        
        Returns:
            gates: (n,) per-sample gate weights ∈ (0, 1)
        """
        n, K = P_soft.shape
        
        # Weighted cluster statistics
        cluster_weights = P_soft.sum(dim=0)  # (K,) sum of probabilities per cluster
        
        # Weighted mean per cluster: Σ_i P_ik * r_i / Σ_i P_ik
        weighted_sum = (P_soft * residuals.unsqueeze(1)).sum(dim=0)  # (K,)
        weighted_mean = weighted_sum / cluster_weights.clamp(min=1e-8)
        
        # Weighted std per cluster
        diff_sq = (residuals.unsqueeze(1) - weighted_mean.unsqueeze(0)) ** 2
        weighted_var = (P_soft * diff_sq).sum(dim=0) / cluster_weights.clamp(min=1e-8)
        cluster_std = torch.sqrt(weighted_var.clamp(min=1e-8))
        
        # Gate per cluster (sigmoid activation, same as CAGate)
        std_median = torch.median(cluster_std)
        raw_gates = torch.sigmoid(self.gate_alpha * (std_median / cluster_std.clamp(min=1e-8) - 1))
        
        # Per-sample gate = soft cluster-weighted sum of cluster gates
        gates = (P_soft * raw_gates.unsqueeze(0)).sum(dim=1)  # (n,)
        
        return gates
    
    def entropy_regularization(self, P_soft):
        """
        Entropy of cluster assignments. Maximizing entropy prevents mode collapse.
        H(P) = -Σ_i Σ_k P_ik log(P_ik) / n
        """
        log_P = torch.log(P_soft.clamp(min=1e-8))
        entropy_per_sample = -(P_soft * log_P).sum(dim=1)  # (n,)
        return entropy_per_sample.mean()  # scalar
    
    def fit(self, X, n_seeds=10, verbose=True, device='cuda'):
        """
        Fit SSCAGate on data X (n×d).
        
        Returns:
            dict with base_edges, gate_edges, cluster_assignments, history
        """
        n, d = X.shape
        Xg = X.to(device)
        
        base_edges_all = []
        gate_edges_all = []
        cluster_history = []
        
        for seed in range(n_seeds):
            torch.manual_seed(seed)
            np.random.seed(seed)
            
            if verbose:
                print(f'  SSCAGate seed {seed+1}/{n_seeds}...', end='', flush=True)
            
            # --- Baseline: standard NOTEARS ---
            W_base = torch.zeros(d, d, requires_grad=True, device=device)
            be = self._run_notears_baseline(Xg, W_base)
            base_edges_all.append(be)
            
            # --- SSCAGate: joint optimization ---
            # Re-init W and P
            self.W = nn.Parameter(torch.zeros(d, d, device=device))
            self.initialize_assignments(n, device)
            
            opt_W = torch.optim.Adam([self.W], lr=self.lr_W)
            opt_P = torch.optim.Adam([self.P_logits], lr=self.lr_P)
            
            rho, alpha = 1.0, 0.0
            
            for o in range(self.outer):
                for i in range(self.inner):
                    opt_W.zero_grad()
                    opt_P.zero_grad()
                    
                    M = torch.eye(d, device=device) - self.W
                    sq = (Xg @ M.T) ** 2  # (n, d)
                    residuals = sq.mean(dim=1)  # (n,)
                    
                    P_soft = self.get_soft_clusters()
                    gates = self.compute_cluster_gates(residuals, P_soft)
                    
                    # Gated reconstruction loss
                    loss_recon = (gates * sq.sum(dim=1)).sum() / gates.sum().clamp(min=1)
                    
                    # DAG constraint
                    h = torch.trace(torch.linalg.matrix_exp(self.W * self.W)) - d
                    loss_dag = 0.5 * rho * h**2 + alpha * h
                    
                    # Entropy regularization (keep clusters diverse)
                    ent = self.entropy_regularization(P_soft)
                    
                    # L1 sparsity
                    l1 = torch.sum(torch.abs(self.W))
                    
                    loss = loss_recon + self.lambda_dag * loss_dag \
                           - self.beta_entropy * ent + self.gamma_l1 * l1
                    
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.W, 10.0)
                    torch.nn.utils.clip_grad_norm_(self.P_logits, 5.0)
                    opt_W.step()
                    opt_P.step()
                
                with torch.no_grad():
                    hv = (torch.trace(torch.linalg.matrix_exp(self.W * self.W)) - d).item()
                if abs(hv) < 1e-8:
                    break
                if abs(hv) > 1e-6:
                    alpha = alpha + rho * hv
                rho = min(5 * rho, 1e12)
                if torch.isnan(self.W).any() or torch.isinf(self.W).any():
                    break
            
            ge = (torch.abs(self.W.detach()) > 0.3).float().sum().item()
            gate_edges_all.append(ge)
            
            # Record cluster assignment
            clusters = self.get_hard_clusters().cpu().numpy()
            cluster_sizes = np.bincount(clusters, minlength=self.K)
            cluster_history.append(cluster_sizes)
            
            if verbose:
                print(f' base={be} gate={ge} delta={ge-be:+d} K_eff={np.sum(cluster_sizes>0)}/{self.K}')
        
        return {
            'base_edges': base_edges_all,
            'gate_edges': gate_edges_all,
            'base_mean': np.mean(base_edges_all),
            'gate_mean': np.mean(gate_edges_all),
            'delta': np.mean(gate_edges_all) - np.mean(base_edges_all),
            'cluster_history': [c.tolist() for c in cluster_history],
            'K_effective': int(np.mean([np.sum(c>0) for c in cluster_history])),
        }
    
    def _run_notears_baseline(self, Xg, W):
        """Standard NOTEARS without gate (shared with CAGate benchmark)."""
        d = W.shape[0]
        rho, alpha = 1.0, 0.0
        opt = torch.optim.Adam([W], lr=self.lr_W)
        for o in range(self.outer):
            for i in range(self.inner):
                opt.zero_grad()
                M = torch.eye(d, device=Xg.device) - W
                sq = (Xg @ M.T) ** 2
                loss_d = sq.mean()
                h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
                loss = loss_d + 0.5 * rho * h**2 + alpha * h + 0.01 * torch.sum(torch.abs(W))
                loss.backward()
                torch.nn.utils.clip_grad_norm_(W, 10.0)
                opt.step()
            with torch.no_grad():
                hv = (torch.trace(torch.linalg.matrix_exp(W * W)) - d).item()
            if abs(hv) < 1e-8: break
            if abs(hv) > 1e-6: alpha = alpha + rho * hv
            rho = min(5 * rho, 1e12)
            if torch.isnan(W).any() or torch.isinf(W).any(): break
        return (torch.abs(W.detach()) > 0.3).float().sum().item()


# ============================================================================
# Quick validation: run on synthetic data, compare with CAGate
# ============================================================================
if __name__ == '__main__':
    import time
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f'Device: {device}')
    
    # Generate synthetic data with known cluster structure
    print('\nGenerating synthetic clustered data (d=30, n=200, K_true=3)...')
    n, d, K_true = 200, 30, 3
    X = []
    cid_true = []
    for k in range(K_true):
        nk = n // K_true
        # Each cluster has different covariance structure
        cov = torch.eye(d) + 0.3 * torch.randn(d, d)
        cov = cov @ cov.T / d  # Make PSD
        mean = torch.randn(d) * 2 * k  # Shifted means
        Xk = torch.distributions.MultivariateNormal(mean, cov).sample((nk,))
        X.append(Xk)
        cid_true.extend([k] * nk)
    X = torch.cat(X).float()
    cid_true = torch.tensor(cid_true)
    
    print(f'Data: {X.shape}, True clusters: {K_true}')
    
    # SSCAGate
    print('\n--- SSCAGate (our V3) ---')
    model = SSCAGate(d=d, K=8, outer=20, inner=150, beta_entropy=0.05)
    t0 = time.time()
    result = model.fit(X, n_seeds=5, verbose=True, device=device)
    elapsed = time.time() - t0
    print(f'SSCAGate: base={result["base_mean"]:.1f} gate={result["gate_mean"]:.1f} delta={result["delta"]:+.1f}')
    print(f'  K_effective: {result["K_effective"]} (true K=3)')
    print(f'  Time: {elapsed:.0f}s')
    
    # Compare with CAGate (pre-clustered with K-means)
    print('\n--- CAGate (V2, K-means pre-clustered) ---')
    sys.path.insert(0, r'D:\NO.1\cdsm_patent_upgrades')
    from cluster_aware_loss import cluster_gate
    
    from sklearn.cluster import KMeans
    cid_km = torch.tensor(KMeans(n_clusters=5, random_state=0).fit_predict(X.numpy()))
    
    def run_cagate(X, cid, device='cuda'):
        d = X.shape[1]
        Xg = X.to(device)
        W = torch.zeros(d, d, requires_grad=True, device=device)
        rho, alpha = 1.0, 0.0
        opt = torch.optim.Adam([W], lr=0.002)
        for o in range(20):
            for i in range(150):
                opt.zero_grad()
                M = torch.eye(d, device=device) - W
                sq = (Xg @ M.T) ** 2
                res = sq.mean(dim=1)
                gates, _ = cluster_gate(res, cid.to(device), alpha=0.5)
                loss_d = (gates * sq.sum(dim=1)).sum() / gates.sum().clamp(min=1)
                h = torch.trace(torch.linalg.matrix_exp(W * W)) - d
                loss = loss_d + 0.5 * rho * h**2 + alpha * h + 0.01 * torch.sum(torch.abs(W))
                loss.backward()
                torch.nn.utils.clip_grad_norm_(W, 10.0)
                opt.step()
            with torch.no_grad():
                hv = torch.trace(torch.linalg.matrix_exp(W * W)).item() - d
            if abs(hv) < 1e-8: break
            if abs(hv) > 1e-6: alpha += rho * hv
            rho = min(5 * rho, 1e12)
        return (torch.abs(W.detach().cpu()) > 0.3).float().sum().item()
    
    base_edges, gate_edges = [], []
    t0 = time.time()
    for seed in range(5):
        torch.manual_seed(seed); np.random.seed(seed)
        be = model._run_notears_baseline(X.to(device), torch.zeros(d,d,requires_grad=True,device=device))
        base_edges.append(be)
        ge = run_cagate(X, cid_km, device)
        gate_edges.append(ge)
    elapsed = time.time() - t0
    
    bm, gm = np.mean(base_edges), np.mean(gate_edges)
    print(f'CAGate:   base={bm:.1f} gate={gm:.1f} delta={gm-bm:+.1f}')
    print(f'  Time: {elapsed:.0f}s')
    
    print(f'\n{"="*50}')
    print(f'SUMMARY: SSCAGate >= CAGate ? {"YES" if result["delta"] >= (gm-bm) else "CLOSE"}')
    print(f'{"="*50}')
