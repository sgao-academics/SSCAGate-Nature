# Replication Index — SSCAGate Phase Transition (Nature Submission)

> Generated: 2026-06-01 | Updated: 2026-06-05 — ED figures consolidated into single script `_gen_ed_figures_v2.py` (4 panels, one run). Old figures archived.

## Data Sources (All Public)

| Data | Source | Access |
|------|--------|--------|
| TCGA 33 cancer types (HiSeqV2) | UCSC Xena / GDC | `cancer_application/scripts/download_tcga.py` |
| TCGA PANCAN methylation | Firehose Broad GDAC | `cancer_application/scripts/download_methylation.py` |
| DepMap CRISPR (1190 cell lines) | depmap.org | Direct download |
| MNIST | yann.lecun.com | `torchvision.datasets.MNIST` |
| CIFAR-10 | cs.toronto.edu | `torchvision.datasets.CIFAR10` |
| PBMC 3k/6k/10k | 10x Genomics | Scanpy built-in |
| 20 Newsgroups | UCI repository | `sklearn.datasets.fetch_20newsgroups` |
| Synthetic DAGs | Script-generated | `make_dag(seed=42)` (deterministic) |

---

## Paper Figure → Script Mapping

### Main Figures (Nature Submission V16, 2026-06-04)

| Figure | Script | Data Source | Seeds | Output | Notes |
|--------|--------|-------------|:--:|--------|-------|
| **Fig 1: 5-modality composite** (2x2 + full-width bottom) | `_gen_fig1_composite.py` | `_gen_panel_B_v2.py` (b), `_gen_qianwen_figs.py` (a/d/c/e), `mega_33_full.json`, multi-modal data | 10 | `Fig1_Five_Modality_Composite.png/pdf` | New layout: a/d upper, b/c middle, e bottom. CVD-safe Panel B. |
| **Fig 2: Universal Bias-Variance Scaling** | `_gen_all_main_figs.py` (V7) | `mega_33_full.json`, `mnist_phase/ckpt.json`, `scrna_phase/ckpt.json`, `text_phase/ckpt.json`, `cdsm_upgrade/ckpt.json`, `synth_phase_results.json` | 3-10 | `Fig2_Universal_Scaling.png/pdf` | Dual-panel: theory curves + decision framework |
| **Panel B (CVD-safe) standalone** | `_gen_panel_B_v2.py` | `results/b100_resample_results.json` | 100 | `Panel_B_resampling.png/pdf` | Okabe-Ito palette, legend inside axes |
| **Qianwen review figures (all)** | `_gen_qianwen_figs.py` | Multi-source (see script) | 10 | `千问审稿_新图/*.png/pdf` | Panel B disabled; use `_gen_panel_B_v2.py` instead |

### Legacy Figure Scripts (pre-V16, kept for reference)

| Figure | Script | Output |
|--------|--------|--------|
| Fig 1a: Phase transition scatter | `_gen_all_main_figs.py` | `fig1_phase_transition.png/pdf` |
| Fig 1b: Within-cancer resampling | `_gen_all_main_figs.py` | `fig2_within_cancer.png/pdf` |
| Fig 1c: Crossover detail | `_gen_all_main_figs.py` | `fig3_crossover_detail.png/pdf` |
| Fig 1d: Literature overlay | `_gen_all_main_figs.py` | `fig4_literature_overlay.png/pdf` |
| Fig 1e: Cross-modal | `_gen_all_main_figs.py` | `fig5_cross_modal.png/pdf` |
| Old composite Fig 1 (v1, 5 single figs) | `scripts/_gen_fig1_v2.py` | `Fig1_Composite.png/pdf` |
| Legacy Fig 2 mechanism | `scripts/_gen_fig6_mechanism.py` | `fig6_mechanism.png/pdf` |

### Extended Data Figures (V2 — All Consolidated, 2026-06-05)

| ED Figure | Script | Source File | Data Source | Seeds | Status |
|-----------|--------|------------|-------------|:--:|:--:|
| **ED1: K-sweep heatmap (16 cancers)** | `scripts/_gen_ed_figures_v2.py` | `extended_data/ed_fig1_ksweep_v2.pdf/png` | `results/ksweep_v2_*.json` (16 cancers) + `_ksweep.py` (199 combos) | 3 | ✅ Complete |
| **ED2: Cross-method validation** | `scripts/_gen_ed_figures_v2.py` | `extended_data/ed_fig2_cross_method_v2.pdf/png` | NOTEARS/CAGate/SSCAGate benchmarks, 5 methods × 3 configs | 10 | ✅ Complete |
| **ED3: Phase transition scatter + robustness** | `scripts/_gen_ed_figures_v2.py` | `extended_data/ed_fig3_phase_scatter_v2.pdf/png` | `mega_33_full.json`, PBMC negative control, 4 panels (a-d) | 10 | ✅ Complete |
| **ED4: Hyperparameter sensitivity** | `scripts/_gen_ed_figures_v2.py` | `extended_data/ed_fig4_hyperparam_v2.pdf/png` | `results/hyperparam_sweep_results.json` (216 runs, 9 configs × 8n × 3 seeds) | 3 | ✅ Complete — all 9 configs produce identical gain(n) curves |

**One script generates all 4 ED figures**: `python scripts/_gen_ed_figures_v2.py`
Deprecated old figures archived in `extended_data/_old/`.

---

## Table → Script Mapping

| Table | Script | Data Source | Verification |
|-------|--------|-------------|-------------|
| **Table 1 (main): Benchmark literature n_crit** | `_fix_literature_table.py` | 13 public benchmarks + n_crit formula | `scripts/_verify_all_tables.py` T6 |
| **ED Table 1: 33-cancer d=200 10-seed results** | `scripts/_gen_ed_figures_v2.py` | `results/tcga_d200_10seed.json` | `scripts/_verify_ed_table.py` / `scripts/_verify_all_tables.py` T1 |
| **SI Table S0: High-dim rescue (d=100-500)** | `scripts/build_supplementary.py` | Hardcoded benchmark results | `scripts/_verify_all_tables.py` T2 (structural) |
| **SI Table S1: Pan-cancer SSCAGate (48 configs)** | `scripts/build_supplementary.py` | `results/full_merge.json` (t1 stage) | `scripts/_verify_all_tables.py` T2 |
| **SI Table S1b: SSCAGate d=300 (8 cancers)** | `scripts/build_supplementary.py` | `results/full_merge.json` (t3 stage) | `scripts/_verify_all_tables.py` T2 |
| **SI Note 1: GBM deep-dimensional** | `scripts/build_supplementary.py` | `results/gbm_results.json` | `scripts/_verify_all_tables.py` T3 |
| **SI Note 2: CAGate baseline d=200** | `scripts/build_supplementary.py` | `results/full_merge.json` (t2 stage) | `scripts/_verify_all_tables.py` T2 |
| **SI Note 3: Bias-variance theory** | `scripts/build_supplementary.py` | Mathematical derivation (Lemma 1-3) | Structural |
| **SI Note 4: Cross-modal evidence** | `scripts/build_supplementary.py` | Multi-modal data | `scripts/_verify_all_tables.py` T5 |
| **SI Note 5: DepMap validation** | `scripts/build_supplementary.py` | DepMap 1190 cell lines | `scripts/_verify_all_tables.py` T5 |
| **ED Fig 8 / DAGMA benchmark** | `scripts/_bench_dagma_ed.py` | `results/dagma_benchmark.json` | `scripts/_verify_all_tables.py` T4 |

### Table Verification (One Command)

```bash
# Verify ALL tables against their data sources
python scripts/_verify_all_tables.py

# Verify ED Table 1 specifically (cross-validate LaTeX vs JSON)
python scripts/_verify_ed_table.py

# Generate all supplementary tables from data
python scripts/build_supplementary.py
```

*All Δ > 0 at d=200 for all 33 cancers — SSCAGate superiority confirmed at high dimensionality (Phase 9, 2026-06-02). Previous small-d benchmarks showed negative Δ for small-n cancers, consistent with phase transition theory.*

---

## Experiment Phases

### Phase 1: NOTEARS high-dimensional failure (d=100-500)
| Script | Result | Config |
|--------|--------|--------|
| `burn_worker.py` (3 workers) | `burn_results/w1-3.json` | d=100-350, 3 seeds |
| Output: NOTEARS edges = 0 for all d ≥ 150 | | |

### Phase 2: Causal Transformer speedup
| Script | Result | Config |
|--------|--------|--------|
| `master_final.py` (P2) | `burn_results/p2_ckpt.json` | d=200-350, 3 seeds |
| Output: CT 598-1605 edges at d≥200, 6.3x-31x vs NOTEARS | | |

### Phase 3: CAGate vs SSCAGate head-to-head
| Script | Result | Config |
|--------|--------|--------|
| `finish_p34.py` | `burn_results/p3_final.json` | d=30-200, 3 seeds |
| Output: SSCAGate 11/11 wins on synthetic data | | |

### Phase 4: GBM deep-dimensional analysis
| Script | Result | Config |
|--------|--------|--------|
| `gbm_deep2.py` | `burn_results/gbm_results.json` | d=100-500, 5 seeds |

### Phase 5: TCGA pan-cancer sweep (33 cancers)
| Script | Result | Config |
|--------|--------|--------|
| `tcga_mega.py` | `mega_33_full.json` (26MB) | 33 cancers × 3 seeds |
| Output: 27/27 CAGate positive, SSCAGate 16/14/3 split | | |

### Phase 6: Within-cancer resampling (B=5)
| Script | Result | Config |
|--------|--------|--------|
| `_resample_phase.py` | `resample_phase_results.json` | 8 cancers × 5 n-levels × 5 seeds |
| Output: Monotonic convergence of V3 advantage | | |

### Phase 7: B=100 Bootstrap (May 31, 2026)
| Script | Result | Config |
|--------|--------|--------|
| `_burn_b100.py` | `results/b100_resample_results.json` | BRCA + HNSC × 5 n-levels × 100 seeds |
| Output: V3 = -383→-401→-38→-3→+1 (BRCA), -461→-422→... (HNSC) |
| Status: ✅ Complete (May 31) | |

### Phase 8: DAGMA boundary condition
| Script | Result | Config |
|--------|--------|--------|
| `_dagma_phase_test.py` | `dagma_phase_results.json` | BRCA n=50-800, 10 seeds, log-det acyclicity |
| Output: DAGMA baseline 249-696 edges; K-means gating *reduces* edges (all Δ negative) |
| Key finding: Phase transition is specific to matrix-exponential DAG constraints | | |

### Phase 9: TCGA d=200 unified 10-seed sweep (June 2, 2026)
| Script | Result | Config |
|--------|--------|--------|
| `_run_tcga_d200.py` | `results/tcga_d200_10seed.json` | 33 cancers × d=200 × 10 seeds |
| Output: NOTEARS = 0 for ALL 33 cancers (d=200 death line confirmed); all Δ > 0 |
| Key finding: SSCAGate wins on all 33 cancers at d=200; no exceptions, no ties | | |

### Phase 10: NOTEARS Hyperparameter Sensitivity Sweep (June 3, 2026) 🆕
| Script | Result | Config |
|--------|--------|--------|
| `scripts/run_hyperparam_sweep.py` | `results/hyperparam_sweep_results.json` | TCGA BRCA, d=100, 9 hyperparam configs × 8n × 3 seeds = 216 runs |
| Figure: `scripts/generate_fig4.py` → `extended_data/ed_fig4_hyperparam_real.png` | | |
| Time: 5778s (96.3min) on CUDA (RTX 5060) | | |
| Key finding: ALL 9 (λ₁ ∈ {0.05,0.10,0.30}, w_thr ∈ {0.1,0.3,0.5}) configurations produce **numerically identical** Δ-vs-n curves |
| n≤200: adaptive K=1, Δ=0; n=300: K=2, Δ=+48; n=500: K=4, Δ=+248 |
| Conclusion: Phase transition is determined by data structure (n/d ratio), not optimizer hyperparameters | | |

---

## Deterministic Reproducibility

| Check | Status |
|-------|:--:|
| All `make_dag()` use fixed seed (42) | ✅ |
| All NOTEARS/CAGate/SSCAGate specify seed | ✅ |
| K-means initialization: fixed `random_state` | ✅ |
| Data normalization: deterministic z-score | ✅ |
| All public data: URLs documented | ✅ |
| CDSM code: open-source (MIT) at github.com/gsd3247186514-cell/cdsm | ✅ |
| Synthetic data: script-generated, no external dependency | ✅ |
| **All scripts use relative paths** (no hardcoded `D:\NO.1`) | ✅ |
| **Figure generation verified end-to-end** (2026-06-01) | ✅ |
| **Table generation verified end-to-end** (2026-06-01) | ✅ |
| **Pre-computed results included** (reviewer can skip experiments) | ✅ |

---

## Quick Reproduce (Post Patent Filing)

```bash
# All commands run from the replication package root directory.
# Prerequisites: Python 3.10+, pip packages (see requirements.txt)

# 1. Install dependencies
pip install -r requirements.txt

# 2. Reproduce Nature Figure 1 (5-modality composite, CVD-safe) — uses pre-computed results/
python _gen_qianwen_figs.py             # Generate panels a/d/c/e
python _gen_panel_B_v2.py               # Generate CVD-safe Panel B
python _gen_fig1_composite.py           # Combine into 5-panel composite
# Output: Fig1_Five_Modality_Composite.png/pdf

# 3. Reproduce Figure 2 (Universal Bias-Variance Scaling)
python _gen_all_main_figs.py            # Generates Fig2_Universal_Scaling.png/pdf + legacy panels

# 4. Reproduce extended data figures (V2 — all 4 in one run)
python scripts/_gen_ed_figures_v2.py

# 5. Generate all tables from data (Supplementary Information)
python scripts/build_supplementary.py

# 6. Verify all tables against data sources (0 issues expected)
python scripts/_verify_all_tables.py

# 7. (Optional) Merge individual K-sweep files
python scripts/_merge_ksweep.py

# 8. (Optional) Re-run experiments — requires TCGA data download first
# python scripts/tcga_mega.py           # 33-cancer sweep (~2.5 hr)
# python _burn_b100.py                  # B=100 bootstrap (~8 hr)

# 9. Compile paper (requires LaTeX)
# pdflatex sscagate_nature.tex
# pdflatex extended_data.tex
```

---

## File Inventory

| Category | Count | Size |
|----------|:--:|------|
| Experiment scripts | ~30 | ~200KB |
| Result JSON files | ~50 | ~80MB |
| Main figures (PDF + PNG) | 15 | ~2.5MB |
| Extended Data figures (PDF + PNG) | 4 | ~1.2MB |
| TCGA raw data (.tsv) | 33 | ~1.2GB |
| CDSM source (.py) | ~20 | ~120KB |
| **Total reproducible package** | **~170 files** | **~1.3GB** |

---

*Note: Code will be publicly released on GitHub after patent filing. All data are from public repositories as documented above. For review purposes, the complete local replication package is available at `D:\NO.1\Replication_Package\`.*
