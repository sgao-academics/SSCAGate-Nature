# SSCAGate Nature -- Replication Package

Replication package for: **"Sample-Size Phase Transition Ends the Hard-versus-Soft Clustering Debate"**

Shuaidong Gao, Chongqing Institute of Foreign Studies (gsd3247186514@gmail.com)

---

## Quick Start (5 minutes)

```bash
# 1. Install dependencies
pip install torch numpy pandas matplotlib scipy scikit-learn pillow

# 2. Regenerate all figures from pre-computed data
python scripts/generate_all.py --quick

# 3. Verify tables against data
python scripts/generate_all.py --quick --verify
```

Output: `main_figure/` (Fig1 + Fig2 PNG/PDF) and `ED_figure/` (ED1-4 PNG/PDF).

---

## Full Reproduction (GPU recommended, 2-4 hours)

```bash
# 1. Download TCGA gene expression data (~300MB)
python scripts/download_tcga.py

# 2. Run experiments + regenerate figures
python scripts/generate_all.py --full --verify
```

---

## Package Structure

```
SSCAGate_Nature_Replication/
├── scripts/                     # All Python scripts
│   ├── generate_all.py          # Master orchestrator
│   ├── gen_fig1.py              # Fig1 composite (5 panels, unified)
│   ├── gen_fig2.py              # Fig2 universal bias-variance scaling
│   ├── gen_ed_fig1.py           # ED Figure 1: K-sweep heatmap
│   ├── gen_ed_fig2.py           # ED Figure 2: Phase transition + robustness
│   ├── gen_ed_fig3.py           # ED Figure 3: Cross-method validation
│   ├── gen_ed_fig4.py           # ED Figure 4: Hyperparameter sensitivity
│   ├── nature_style.py          # Nature journal styling
│   ├── build_supplementary.py   # Supplementary tables
│   ├── download_tcga.py         # TCGA data downloader
│   ├── _verify_all_tables.py    # Table verification
│   ├── _verify_ed_table.py      # ED table verification
│   ├── tcga_mega.py             # TCGA 33-cancer sweep
│   ├── _burn_b100.py            # B=100 bootstrap resampling
│   ├── _resample_phase.py       # Cross-domain resampling
│   ├── _ksweep.py               # K-sensitivity sweep
│   ├── _ksweep_worker_v2.py     # K-sweep NOTEARS worker
│   ├── _dagma_phase_test.py     # DAGMA phase test
│   ├── _bench_dagma_ed.py       # DAGMA formal benchmark
│   ├── run_hyperparam_sweep.py  # Hyperparameter sweep
│   └── _run_small_cancers.py    # Small cancer validation
├── src/                         # Core algorithm source
│   ├── sscagate.py              # SSCAGate implementation
│   ├── cluster_aware_loss.py    # Cluster-aware gating
│   └── nature_style.py          # Matplotlib styling
├── main_figure/                 # Fig1 + Fig2 (pre-built)
├── ED_figure/                   # ED1-4 (pre-built)
├── results/                     # Pre-computed benchmark data (40+ JSONs)
├── README.md
├── REPLICATION_INDEX.md
└── requirements.txt
```

---

## Key Figures & Their Scripts

| Figure | Generation Script | Data Source |
|:--|:--|:--|
| Fig1 (composite, 5 panels) | gen_fig1.py | mega_33_full.json, b100_resample_results.json, nd_ratio_analysis.json |
| Fig2 (bias-variance law) | gen_fig2.py | critical_n_fit.json, multi-modal checkpoint data |
| ED1 (K-sweep) | gen_ed_fig1.py | ksweep_results.json, ksweep_v2_*.json |
| ED2 (phase dynamics) | gen_ed_fig2.py | nd_ratio_analysis.json, clustering_ablation.json, pbmc_phase_curve.json |
| ED3 (cross-method) | gen_ed_fig3.py | dagma_benchmark.json, methylation_crossmodality.json |
| ED4 (hyperparameter) | gen_ed_fig4.py | hyperparam_sweep_results.json, timing_benchmark.json |

---

## Requirements

- Python 3.10+
- PyTorch 2.0+ (CUDA optional for quick mode, recommended for full)
- numpy, pandas, matplotlib, scipy, scikit-learn, pillow
- GPU with 8GB+ VRAM for full experiment reproduction

## License

MIT License. Code available for peer review. Patent pending (Chinese Patent Application, May 2026).
